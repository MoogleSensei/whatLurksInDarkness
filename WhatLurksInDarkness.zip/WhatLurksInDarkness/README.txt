What Lurks in the Dark

An Introductory Game by Sean Miller

-----------------------------------

I made this game as part of the Ludum Dare 32 Compo. Original compile date was on 04/19/2015. Around 7:30pm , if you're curious. (that's an hour and a half before the compo ended)
The premise of the competition is that I had 48 hours to create a game entirely from scratch - code, graphics, audio, etc - following the vague theme: "an unconventional weapon"
Thus was born this game about a balding man with a flashlight who ventures into his basement to find some yams. BUT THEN SUDDENLY MONSTERS AND MAGIC ROCKS!


To play this game - not INSTALL it, because there is no install for this bad boy - follow these steps:

Linux users:

Download and install the latest version of LOVE
(at the time of this game's creation, this is 0.9.2, available at https://love2d.org/)
Obtain the .love file that contains this readme
Run LOVE with the .love file as the argument

Windows users:

Obtain the pretty .zip file that contains this readme
Run WhatLurksinDarkness.exe


Thank you so much for taking the time to play my first ever game! Have fun!



Some hints:

Yellow light stones are still charging up, green light stones are fully charged and will emit their own light until they run out of charge

If you are close enough to a light stone, you will be able to hear its tone. The higher the pitch, the more charged it is! (This even works through walls)

Enemies make the occasional noise when close enough to the player

Enemies will start to run away if they are exposed to light long enough. They wioll always run ddirectly away from the player, so try to force them into a corner!

Eventually, enemies will die, and their bodies remain to show how many you've killed. Well done, you.
